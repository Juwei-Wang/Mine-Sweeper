import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;


public class GameObjectTest {
    @Test
    public void test_GameObject_non_default_constructor()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        GameObject gameObject = new GameObject(board,6,6);
        int[] a = gameObject.getCoords();

        assertEquals("should be 6 ", 6, a[0]);
        assertEquals("should be 6 ", 6, a[1]);

    }

    @Test
    public void test_GameObject_non_default_constructor2()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        GameObject gameObject = new GameObject(board,6,6);
        GameObject gameObject1 = new GameObject(board,gameObject);
        int[] a = gameObject1.getCoords();

        assertEquals("should be 6 ", 6, a[0]);
        assertEquals("should be 6 ", 6, a[1]);

    }

    @Test
    public void test_reveal()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        GameObject gameObject = new GameObject(board,6,6);
        gameObject.reveal();

        assertEquals("should be 6 ", true, gameObject.isRevealed());

    }

    @Test
    public void test_hide()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        GameObject gameObject = new GameObject(board,6,6);
        gameObject.hide();

        assertEquals("should be 6 ", false, gameObject.isRevealed());
    }

    @Test
    public void test_getCoords()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        GameObject gameObject = new GameObject(board,5,5);
        int[] a = gameObject.getCoords();

        assertEquals("should be 6 ", 5, a[0]);
        assertEquals("should be 6 ", 5, a[1]);
    }

    @Test
    public void test_getMarker()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        GameObject gameObject = new GameObject(board,5,5);
        char a = gameObject.getMarker();

        assertEquals("should be 6 ", 0, a);
    }

    @Test
    public void test_setMarker()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        GameObject gameObject = new GameObject(board,5,5);
        gameObject.setMarker();
        char a = gameObject.getMarker();

        assertEquals("should be 6 ", 0, a);
    }









}
