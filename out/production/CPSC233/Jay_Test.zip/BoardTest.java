import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;


public class BoardTest {
    @Test
    public void test_Constructor()
    {
        Game game = new Game();
        Board board = new Board(game);
        String a = "player1";
        assertEquals("should be player1 ", a, board.getCurrentGame().getPlayer1().getPlayerName());
    }



    @Test
    public void test_Copy_Constructor()
    {
        Game game = new Game();
        Board board = new Board(game);
        Board board1 = new Board(board);
        String a = "player1";
        assertEquals("should be player1 ", a, board1.getCurrentGame().getPlayer1().getPlayerName());
    }

    @Test
    public void test_getBoardSize()
    {
        Game game = new Game();
        Board board = new Board(game);
        assertEquals("should be player1 ", 0, board.getBoardSize());
    }

    @Test
    public void test_initializeBoard()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        int a = 8;
        System.out.println(board.getBoardField().length);
        assertEquals("should be 8 ", a, board.getBoardField().length);
    }

    @Test
    public void test_displayBoardField()
    {
        Game game = new Game();
        Board board = new Board(game);
        String a = "  X  ";
        assertEquals("should be x", a, board.displayBoardField());
    }

    @Test
    public void test_mineScan()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        int a = 0;
        assertEquals("should be 0 ", a, board.mineScan(6,6,6,6));
    }

    @Test
    public void test_withinBoard()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        boolean a = true;
        assertEquals("should be 0 ", a , board.withinBoard(6,6));
    }

    @Test
    public void test_outSideTheBoard()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(6,6);
        boolean a = false;
        assertEquals("should be 0 ", a , board.withinBoard(9,9));
    }













}
