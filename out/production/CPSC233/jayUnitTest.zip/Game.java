
/**
 * This class is Game class that has special functionality to enable the game running(@see BankAccount).
 * @documentation  Juwei Wang
 * @author Rex Leniczek
 * @version 1.1
 * @since 2019-02-15
 *  * @TODO: There is need to determine whether each menu subtype should simply be a
 *  * subclass of this Menu class...
 */


public class Game {
	private final Settings gameSettings = new Settings(this);
	private final Board gameBoard = new Board(this);
	private final Player player1 = new Human(this);
	private final Player player2 = null;
	private Boolean gameOver = false;
	private int activePlayer = 1;


	/**
	 * Default constructor with no arguments;
	 */
	public Game() {


	}

	public Settings getGameSettings() {
		return gameSettings;
	}

	public Boolean getGameOver() {
		return gameOver;
	}

	public void setGameOver(Boolean gameOver) {
		this.gameOver = gameOver;
	}

	public int getActivePlayer() {
		return activePlayer;
	}

	/*
	 * A method to start the game and judge the game conditions if the game is over.
	 */
	public void start() {
		System.out.println("Game.start()");
		System.out.println(this.gameBoard.displayBoardField());
		while (gameOver == false) {
			if (activePlayer == 1) {
				PlayerController.getInstance().gameTurn(this, player1);
			}
			else if (activePlayer == 2) {
				PlayerController.getInstance().gameTurn(this, player2);
			}
		}
	}

	/**
	 * Gets the setting parameter.
	 * @return	setting representing this game's setting
	 */
	public Settings getSettings() {
		return new Settings(gameSettings);
	}


	/**
	 * Gets the player1 parameter.
	 * @return	player1 representing the first player
	 */
	public Player getPlayer1() {
		return player1;
	}

	/**
	 * Gets the player2 parameter.
	 * @return	player2 representing the second player
	 */
	public Player getPlayer2() {
		return player2;
	}

	/**
	 * Gets the Gameboard parameter.
	 * @return	Gameboard representing the map of board
	 */
	public Board getGameBoard() {
		return gameBoard;
	}


	/**
	 * Sets the annualInterestRate parameter.
	 * @param playerNumber	An int representing the number of players
	 */
	public void setActivePlayer(int playerNumber) {
		this.activePlayer = playerNumber;
	}
}
