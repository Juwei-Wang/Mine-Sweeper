/**
 * Subclass of GameObject
 * @author Rex J. Leniczek
 * @version 0.1
 * @since 2019-02-16
 */

public class Human extends Player {
	private int storePoints = 0;
	private String accountPassword;

	public Human(Game currentGame, Human humanToCopy) {
		this(currentGame);
		this.storePoints = humanToCopy.getStorePoints();
		this.accountPassword = humanToCopy.getAccountPassword();
	}

	public Human(Game currentGame) {
    	this();
    	this.currentGame = currentGame;
    }

    public Human() {
		this.assureNamed();
	}

	/**
	 * Anytime a new Human Player is created, they are asked to provide a non-empty playername.
	 * @TODO: Create a save and load mechanism that stores playernames, player highscores,
	 * in-game points, and a password associated with each playername, required to access
	 * account save. Should recognize when a playername already exists and prompt for the
	 * respective account password.
	 */

	public int getStorePoints() {
		return this.storePoints;
	}

	public String getAccountPassword() {
		return new String(this.accountPassword);
	}

	public void assureNamed() {
		while (this.getPlayerName() == null) {
			System.out.print("Please enter your playername: ");
			if (this.name == null) {
				this.setName("player1");
			}
		}
		System.out.println("Welcome," + this.getPlayerName() + "!");
	}
}
