/**
 * Subclass of GameObject
 * @author Rex J. Leniczek
 * @version 0.1
 * @since 2019-02-16
 */

public class Settings {
	private static final int sizeSmall = 8;
	private static final int sizeMedium = 16;
	private static final int sizeLarge = 24;
	private static final int difficultyEasy = 8;
	private static final int difficultyMedium = 16;
	private static final int difficultyHard = 24;
	private int boardSize = sizeMedium;
	private int gameDifficulty = difficultyMedium;
	private Game currentGame;

	public Settings(Settings settingsToCopy) {
		this.boardSize = settingsToCopy.getBoardSize();
		this.gameDifficulty = settingsToCopy.getGameDifficulty();
		this.currentGame = settingsToCopy.getCurrentGame();
	}

	public Settings(Game currentGame) {
		this.currentGame = currentGame;
	}

	public int getBoardSize() {
		return boardSize;
	}

	public int getGameDifficulty() {
		return gameDifficulty;
	}

	public Game getCurrentGame() {
		return currentGame;
	}

	public void setGameDifficulty(String difficulty) {
			switch (difficulty) {
				case "E":
					this.gameDifficulty = difficultyEasy;
					break;
				case "M":
					this.gameDifficulty = difficultyMedium;
					break;
				case "H":
					this.gameDifficulty = difficultyHard;
					break;
			}
	}

	public void setBoardSize(String size) {
			switch (size) {
				case "S":
					this.boardSize = sizeSmall;
					break;
				case "M":
					this.boardSize = sizeMedium;
					break;
				case "L":
					this.boardSize = sizeLarge;
					break;
			}
	}
}
