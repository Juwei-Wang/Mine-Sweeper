import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class GUI extends Application {
    private int size;
    private int difficulty;
    private Stage window;
    private Scene firstScene, secondScene,thirdScene, fourthScene, fifthScene, sixthScene;
    private Button newGame, goBackToFirstScene, enter, goBackToSecondScene;
    private Button smallBoard, mediumBoard, largeBoard;
    private Button hardGame, mediumGame, easyGame, startGame;
    private Button store, goBackToFourthScene;
    private Button Art, buttonColor, goBackToFifthScene;
    private TextField playerName;
    private GridPane myBoard;
    private Board gameBoard;
    private Game currentGame;
    private Settings gameSettings;

    public class GameHandle implements EventHandler<ActionEvent>{

        @Override
        public void handle(ActionEvent actionEvent) {
            if ( actionEvent.getSource() == enter){
                createMainMenu();
                window.setScene(secondScene);
                System.out.println("Enter name please:");
            }

            else if ( actionEvent.getSource() == newGame){
                createBoardSettings();
                window.setScene(thirdScene);
                currentGame = new Game();
            }

            else if ( actionEvent.getSource() == goBackToFirstScene){
                window.setScene(firstScene);
            }

            else if (actionEvent.getSource() == goBackToSecondScene){
                window.setScene(secondScene);
            }

            else if (actionEvent.getSource() == goBackToFourthScene){
                window.setScene(firstScene);
                playerName.setText("");
            }

            else if (actionEvent.getSource() == goBackToFifthScene){
                window.setScene(fifthScene);
                playerName.setText("");
            }

            else if ( actionEvent.getSource() == largeBoard){
                createSettings();
                getSettings().setBoardSize("L");
                size = getSettings().getBoardSize();
                createBoard(getSettings().getBoardSize(), playerName);
                window.setScene(fourthScene);
            }

            else if ( actionEvent.getSource() == mediumBoard){
                createSettings();
                getSettings().setBoardSize("M");
                size = getSettings().getBoardSize();
                createBoard(getSettings().getBoardSize(), playerName);
                window.setScene(fourthScene);
            }

            else if (actionEvent.getSource() == smallBoard){
                createSettings();
                getSettings().setBoardSize("S");
                size = getSettings().getBoardSize();
                createBoard(getSettings().getBoardSize(), playerName);
                window.setScene(fourthScene);
            }

            else if (actionEvent.getSource() == hardGame){
                getSettings().setGameDifficulty("H");
                difficulty = getSettings().getGameDifficulty();
            }

            else if (actionEvent.getSource() == mediumGame){
                getSettings().setGameDifficulty("M");
                difficulty = getSettings().getGameDifficulty();
            }

            else if (actionEvent.getSource() == easyGame){
                getSettings().setGameDifficulty("E");
                difficulty = getSettings().getGameDifficulty();
            }

            else if (actionEvent.getSource() == store){
                createStore();
                window.setScene(sixthScene);
            }

            else if (actionEvent.getSource() == startGame) {
                currentGame.getGameBoard().initializeBoard(size, difficulty);
                createBoard(difficulty,playerName);
                window.setScene(fifthScene);
            }

            else{
                int row = myBoard.getRowIndex(((Button) actionEvent.getSource()));
                int column = myBoard.getColumnIndex(((Button) actionEvent.getSource()));
                String gameLabel = Character.toString(gameBoard.getObjectAtCoords(row, column).getMarker());
                ((Button) actionEvent.getSource()).setText(gameLabel);
                ((Button) actionEvent.getSource()).setStyle("-fx-base: white;");
            }
        }
    }

    // Starting the GUI display
    @Override
    public void start(Stage primaryStage) throws Exception{
        this.window = primaryStage;


        // Create the welcome page:
        BorderPane welcomePage = new BorderPane();
        Label welcomeToMineSweeper = new Label("Welcome to Minesweeper!");
        enter = new Button("Enter");
        enter.setOnAction(new GameHandle());
        HBox userInput = new HBox();
        Label enterName = new Label("Please enter your name:");
        playerName = new TextField("");
        userInput.getChildren().addAll(enterName, playerName);
        welcomePage.setTop(welcomeToMineSweeper);
        welcomePage.setCenter(userInput);
        welcomePage.setBottom(enter);
        firstScene = new Scene(welcomePage, 400, 100);
        primaryStage.setScene(firstScene);
        primaryStage.show();
    }

    public Settings getSettings() {
        return currentGame.getSettings();
    }

    public void createMainMenu(){
        // Create the Main Menu
        BorderPane Menu = new BorderPane();
        Label mainMenu = new Label("Main Menu");
        VBox menuButtons = new VBox();
        newGame = new Button("New Game");
        newGame.setOnAction(new GameHandle());
        goBackToFirstScene = new Button("Back");
        goBackToFirstScene.setOnAction(new GameHandle());
        menuButtons.getChildren().addAll(newGame,goBackToFirstScene);
        Menu.setTop(mainMenu);
        Menu.setCenter(menuButtons);
        secondScene = new Scene(Menu, 100, 150);
    }

    public void createBoardSettings(){
        // Create board settings
        BorderPane boardSettings = new BorderPane();
        Label chooseBoardSettings = new Label("Choose Board Settings");
        VBox boardButtons = new VBox();
        smallBoard = new Button("Small Board");
        mediumBoard = new Button("Medium Board");
        largeBoard = new Button("Large Board");
        goBackToSecondScene = new Button("Back");
        smallBoard.setOnAction(new GameHandle());
        mediumBoard.setOnAction(new GameHandle());
        largeBoard.setOnAction(new GameHandle());
        goBackToSecondScene.setOnAction(new GameHandle());
        boardButtons.getChildren().addAll(smallBoard, mediumBoard, largeBoard, goBackToSecondScene);
        boardSettings.setTop(chooseBoardSettings);
        boardSettings.setCenter(boardButtons);
        thirdScene = new Scene(boardSettings, 200, 120);
    }

    public void createSettings(){
        // Create difficulty settings
        BorderPane difficultyLevel = new BorderPane();
        Label ChooseDifficulty = new Label("Choose Difficulty");
        VBox difficultyOfGame = new VBox();
        hardGame = new Button("Difficult");
        mediumGame =  new Button("Medium");
        easyGame = new Button("Easy");
        startGame = new Button("Start Game");
        hardGame.setOnAction(new GameHandle());
        mediumGame.setOnAction(new GameHandle());
        easyGame.setOnAction(new GameHandle());
        difficultyOfGame.getChildren().addAll(hardGame, mediumGame, easyGame, startGame);
        difficultyLevel.setTop(ChooseDifficulty);
        difficultyLevel.setCenter(difficultyOfGame);
        fourthScene = new Scene(difficultyLevel, 200, 100);
    }

    public void createBoard(int size, TextField player1){
        BorderPane minesweeper = new BorderPane();
        HBox playerInfo = new HBox();
        Label playerOne = new Label("Player 1:" + player1.getText());
        Label playerTwo = new Label("Player 2: AI");
        playerInfo.getChildren().addAll(playerOne, playerTwo);
        playerInfo.setSpacing(10.0);
        myBoard = new GridPane();
        for (int i = 0; i < size; i++ ){
            for (int j = 0; j < size; j++){
                Button btt = new Button("   ");
                btt.setStyle("-fx-base: black;");
                btt.setOnAction(new GameHandle());
                myBoard.add(btt, i, j);
            }
        }

        HBox playerOptions = new HBox();
        goBackToFourthScene = new Button("Quit Game");
        store = new Button("Store");
        store.setOnAction(new GameHandle());
        playerOptions.getChildren().addAll(store, goBackToFourthScene);
        goBackToFourthScene.setOnAction(new GameHandle());
        minesweeper.setTop(playerInfo);
        minesweeper.setCenter(myBoard);
        minesweeper.setBottom(playerOptions);
        fifthScene = new Scene(minesweeper, 750, 750);

    }

    public void createStore(){
        // Create Store Menu
        BorderPane storeMenu = new BorderPane();
        Label theStore = new Label("Store");
        VBox storeButtons = new VBox();
        Art = new Button("Art");
        Art.setOnAction(new GameHandle());
        buttonColor = new Button("Button Color");
        buttonColor.setOnAction(new GameHandle());
        goBackToFifthScene = new Button("Back to Game");
        goBackToFifthScene.setOnAction(new GameHandle());
        Label myPoints = new Label("My Points: 0");
        storeButtons.getChildren().addAll(Art, buttonColor, goBackToFifthScene, myPoints);
        storeMenu.setTop(theStore);
        storeMenu.setCenter(storeButtons);
        sixthScene = new Scene(storeMenu, 200, 200);

    }

    public static void main(String[] args) {
        launch(args);
    }
}
