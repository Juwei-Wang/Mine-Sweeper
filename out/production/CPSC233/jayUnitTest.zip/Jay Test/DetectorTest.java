import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;


public class DetectorTest {
    @Test
    public void test_Constructor()
    {   Game game = new Game();
        Board board = new Board(game);
        Detector detector = new Detector(board,8,8);
        char a = 43;
        assertEquals("should be player1 ", a, detector.getMarker());
    }

    @Test
    public void test_setMarker()
    {
        Game game = new Game();
        Board board = new Board(game);
        board.initializeBoard(8,8);
        Detector detector = new Detector(board,6,6);
        detector.setMarker();
        int a = detector.getMarker();
        assertEquals("should be player1 ",  a, detector.getMarker());
    }
}
