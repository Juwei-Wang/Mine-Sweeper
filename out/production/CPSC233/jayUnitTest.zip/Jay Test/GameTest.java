import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;


public class GameTest {
    @Test
    public void test_empty_Constructor()
    {
        Game game = new Game();
        int a = 1;
        assertEquals("should be 1 ", a,game.getActivePlayer());
    }

    @Test
    public void test_getGameSettings()
    {
        Game game = new Game();
        int a = 16;
        assertEquals("should be 16 ", a, game.getSettings().getBoardSize());
    }

    @Test
    public void test_getGameOver()
    {
        Game game = new Game();
        assertEquals("should be false ", false, game.getGameOver());
    }

    @Test
    public void test_setGameOver()
    {
        Game game = new Game();
        game.setGameOver(true);
        assertEquals("should be true ", true, game.getGameOver());
    }

    @Test
    public void test_getActivePlayer()
    {
        Game game = new Game();
        assertEquals("should be 1 ", 1, game.getActivePlayer());
    }

    @Test
    public void test_getSettings()
    {
        Game game = new Game();

        assertEquals("should be 16 ", 16, game.getSettings().getBoardSize());
    }

    @Test
    public void test_getPlayer1()
    {
        Game game = new Game();
        String a = "player1";

        assertEquals("should be player1 ", a, game.getPlayer1().getPlayerName());
    }

    @Test
    public void test_getPlayer2()
    {
        Game game = new Game();

        assertEquals("should be null ", null, game.getPlayer2());
    }

    @Test
    public void test_getGameBoard()
    {
        Game game = new Game();

        assertEquals("should be 0 ", 0, game.getGameBoard().getBoardSize());
    }

    @Test
    public void test_setActivePlayer()
    {
        Game game = new Game();
        game.setActivePlayer(5);

        assertEquals("should be 5 ", 5, game.getActivePlayer());
    }




}
