import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;



public class AItest {

    @Test
    public void test_empty_Constructor()
    {
        AI ai = new AI();
        String a = "Computer";
        assertEquals("should be computer ", a, ai.getPlayerName());
    }



    @Test
    public void test_non_default_Constructor()
    {
        Game game = new Game();
        AI ai = new AI(game);
        String a = "Computer";
        assertEquals("should be computer ", a, ai.getPlayerName());
    }







}
