

/**
 * This class is a class of the board that has special functionality  to show the board
 * (@see Board).
 *
 * @documentation  Juwei Wang
 * @author Rex Leniczek
 * @version 1.1
 * @since 2019-02-15
 */


import java.util.*;

public class Board {
	private int boardSize;
	private int gameDifficulty;
	private GameObject[][] boardField;
	private Game currentGame;


	/**
	 * Constructor with the following parameters as arguments:
	 * @param currentGame	A game representing the game that the player is playing.
	 */
	public Board(Game currentGame) {
		this.currentGame = currentGame;
	}


	/**
	 * Constructor with the following parameters as arguments:
	 * @param currentGame	A game representing the game that the player is playing.
	 * @param gameSettings	A setting representing the setting of game
	 */
	public Board(Game currentGame, Settings gameSettings) {
		this(currentGame);
		this.boardSize = gameSettings.getBoardSize();
		this.gameDifficulty = gameSettings.getGameDifficulty();
	}

	/**
	 * A copy Constructor with the following parameters as arguments:
	 * @param boardToCopy	A board representing the board for the current player.
	 */
	public Board(Board boardToCopy) {
		this.currentGame = boardToCopy.getCurrentGame();
		this.boardSize = currentGame.getSettings().getBoardSize();
		this.gameDifficulty = currentGame.getSettings().getGameDifficulty();
		this.boardField = boardToCopy.getBoardField();
	}



	// public Board() {
	// }


	/**
	 * Gets the annualInterestRate parameter.
	 * @return	GameObject representing the position of certain item.
	 */
	public GameObject getObjectAtCoords(int xPos, int yPos) {
		return boardField[xPos][yPos];
	}


	/**
	 * Gets the annualInterestRate parameter.
	 * @return	int representing the size of boardsize.
	 */
	public int getBoardSize() {
		return boardSize;
	}

	/**
	 * Gets the annualInterestRate parameter.
	 * @return	Game representing the game the the players are playing.
	 */
	public Game getCurrentGame() {
		return currentGame;
	}

	/**
	 * Gets the annualInterestRate parameter.
	 * @return	GameObjects[][] representing the digital array of the board.
	 */
	public GameObject[][] getBoardField(){
		GameObject[][] copyField = new GameObject[boardSize][boardSize];
		for (int row = 0; row < boardSize; row++) {
			for (int col = 0; col < boardSize; col++) {
				copyField[row][col] = this.getObjectAtCoords(col, row);
			}
		}
		return copyField;
	}


	/*	*//**
	 * A method to deposit the monthly interest, calculated by dividing the annual interest rate
	 * by 12 and multiplying the result by the current balance.
	 *
	 */
	public void initializeBoard() {
		// Creating the Field
		Random rand = new Random();
		boardField = new GameObject[boardSize][boardSize];
		for (int row = 0; row < boardSize; row++) {
			for (int col = 0; col < boardSize; col++) {
				if (rand.nextInt(100) <= gameDifficulty)
					boardField[row][col] = new Mine(this, col, row);
				else {
					boardField[row][col] = new Detector(this, col, row);
				}
			}
		}
		for (int row = 0; row < boardSize; row++) {
			for (int col = 0; col < boardSize; col++) {
				boardField[row][col].setMarker();
			}
		}
	}


	/*	*//**
	 * A method to create an initial board.
	 */
	public void initializeBoard(int size, int difficulty) {
		this.boardSize = size;
		this.gameDifficulty = difficulty;

		// Creating the Field
		Random rand = new Random();
		boardField = new GameObject[size][size];
		for (int row = 0; row < boardSize; row++) {
			for (int col = 0; col < boardSize; col++) {
				if (rand.nextInt(100) <= difficulty)
					boardField[row][col] = new Mine(this, col, row);
				else {
					boardField[row][col] = new Detector(this, col, row);
				}
			}
		}
		for (int row = 0; row < boardSize; row++) {
			for (int col = 0; col < boardSize; col++) {
				boardField[row][col].setMarker();
			}
		}
	}


	/*	*//**
	 * A method to enable the boardField to be showed.
	 * @return	String representing the string that the text-version board.
	 */
	public String displayBoardField() {
		StringBuilder builder = new StringBuilder();
		builder.append("  X");
		for (int col = 0; col < boardSize; col++)
			if (col < 11) builder.append("  " + col);
			else builder.append(" " + col);
		builder.append("\n");
		for (int row = 0; row < boardSize; row++) {
			if (row < 10) builder.append("  " + row);
			else builder.append(" " + row);
			for (int col = 0; col < boardSize; col++) {
				builder.append("  ");
				if (boardField[row][col].isRevealed() == true)
					builder.append(boardField[row][col].getMarker());
				else
					builder.append('#');
			}
			builder.append("\n");
		}
		return builder.toString();
	}


	/*	*//**
	 * A method to calculate the number of mine.
	 * @return	int representing the number of board.
	 */
	public int mineScan(int x1, int x2, int y1, int y2) {
		int mineScanCount = 0;
		for (int row = y1; row <= y2; row++) {
			for (int col = x1; col <= x2; col++) {
				if (boardField[row][col] instanceof Mine)
					mineScanCount += 1;
			}
		}
		return mineScanCount;
	}


	/*	*//**
	 * A method to identify the condition that the mines are both in the board area
	 * @return	boolean representing weather the tokens were in the board.
	 */
	public Boolean withinBoard(int xPos, int yPos) {
		if (xPos >= 0 && xPos < this.boardSize && yPos >= 0 && yPos < this.boardSize)
			return true;
		else return false;
	}

	/*	*//**
	 * A method to show the area that has no mine inside
	 *
	 */
	public void reveal(int xPos, int yPos) {
		GameObject originalgameObject = this.getObjectAtCoords(xPos, yPos);
		originalgameObject.reveal();

		// Section to reveal additional GameObjects
		if (originalgameObject.getMarker() == 32) {
			int colS, colE, rowS, rowE;
			colS = colE = rowS = rowE = 1;
			if (xPos == 0) colS = 0;
			else if (xPos == this.getBoardSize() - 1) colE = 0;
			if (yPos == 0) rowS = 0;
			else if (yPos == this.getBoardSize() - 1) rowE = 0;
			for (int col = xPos - colS; col <= xPos + colE; col++) {
				for (int row = yPos - rowS; row <= yPos + rowE; row++) {
					GameObject additionalGameObject = this.getObjectAtCoords(col, row);
					if (additionalGameObject instanceof Detector && additionalGameObject.isRevealed() == false)
						this.reveal(col, row);
				}
			}

		}
	}
}
