
/**
 * This class is GameObject class that has special functionality to give the computer weather
 * the area has bone or not. also reveal the status of  the flied(@see BankAccount).

 * @documentation  Juwei Wang
 * @author Rex Leniczek
 * @version 1.1
 * @since 2019-02-15
 */


public class GameObject {
	protected Board ownerBoard;
	protected int[] coords = new int[2];
	protected char marker = 0;
	protected boolean revealedBoolean = false;


	/**
	 * Constructor with the following parameters as arguments:
	 * @param board	A board representing board that the player currently use..
	 * @param xPos	An int representing the horizontal position of the filed.
	 * @param yPos	An int representing the vertical position of the filed.
	 */

	public GameObject(Board board, int xPos, int yPos) {
		this.coords[0] = xPos;
		this.coords[1] = yPos;
		this.ownerBoard = board;
	}


	/**
	 * Constructor with the following parameters as arguments:
	 * @param board	A board representing board that the player currently use..
	 * @param objectToCopy	A gameObject representing game that used to be copied.
	 */
	public GameObject(Board board, GameObject objectToCopy) {
		this.coords = objectToCopy.getCoords();
		this.marker = objectToCopy.getMarker();
		this.ownerBoard = board;
	}


	/*	*//**
	 * A method to change the boolean value if the mine has been revealed.
	 *
	 */
    public void reveal() {
		this.revealedBoolean = true;
    }






	/*	*//**
	 * A method to change the boolean value if the mine has been hided.
	 *
	 */
	public void hide() {
		this.revealedBoolean = false;
	}



	/*	*//**
	 * A method to return the condition weather the mine has been revealed or not.
	 * @return  boolean	 get the condition weather the mine has been revealed or not.
	 */
	public boolean isRevealed() {
		return revealedBoolean;
	}


	/**
	 * Gets the int[] parameter.
	 * @return	int[] representing the digital array of weather there is a mine in the area.
	 */
	public int[] getCoords() {
		int[] copyCoords = new int[2];
		copyCoords[0] = coords [0];
		copyCoords[1] = coords [1];
		return copyCoords;
	}


	/**
	 * Gets the Maker parameter.
	 * @return	char representing the mark of the token.
	 */
	public char getMarker() {
		return marker;
	}

	/**
	 * Sets the annualInterestRate parameter.
	 *
	 */
	public void setMarker() {

	}
}
