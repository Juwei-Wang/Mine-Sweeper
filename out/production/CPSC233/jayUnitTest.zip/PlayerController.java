/**
 * Subclass of GameObject
 * @author Rex J. Leniczek
 * @version 0.1
 * @since 2019-02-20
 */

import java.util.*;

public class PlayerController {
	private static PlayerController playerControllerInstance = null;
	private Scanner scanner = new Scanner(System.in);

	public PlayerController() {

	}

	public static PlayerController getInstance() {
		if(playerControllerInstance == null){
			playerControllerInstance = new PlayerController();
		}
		return playerControllerInstance;
	}

	public String getPlayerInput() {
		return scanner.next();
	}

	// Consider applying formatting style and using it to detect different command styles
	public Boolean gameTurn(Game currentGame, Player player) {
		String userInput;
		String coords[];
		Board currentGameBoard = currentGame.getGameBoard();
		// Fix to be a boolean (right now is int to accomodate mineScan method return type)
		int mineCount;
		System.out.print(player.getPlayerName() + ", enter your guess: ");
		userInput = this.getPlayerInput();
		player.addMove(userInput);

		// Section for guessing at coordinates
		coords = userInput.split(":");
		if (coords.length == 2) {
			int row = this.toInteger(coords[0]);
			int col = this.toInteger(coords[1]);
			if ((row != -1 && col != -1) && (currentGameBoard.withinBoard(col, row) == true)) {
				System.out.println("(valid guess)");
				currentGame.getGameBoard().reveal(col, row);
			}
			else System.out.println("(invalid entry)");
		}
		else System.out.println("(invalid formatting)");

		// Section for other possible commands
		if (userInput.toUpperCase() == "MT") {
			System.out.println(player.getMoveTrace());
		}

		System.out.println(currentGame.getGameBoard().displayBoardField());
		return false;
		// if (isMine = true) ;
	}

	private int toInteger(String str) {
		int num;
		try {
			num = Integer.parseInt(str);
		}
		catch(NumberFormatException nfe) {
			return -1;
		}
		return num;
	}
}
