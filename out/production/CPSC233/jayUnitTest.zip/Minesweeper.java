/**
 * Subclass of GameObject
 * @author Rex J. Leniczek
 * @version 0.1
 * @since 2019-02-16
 */

public class Minesweeper {
	// Give minesweeperInstance a value to record the game running situation
	private static Minesweeper minesweeperInstance = null;

	/* 
	    Test the game's situation and return the game data:
	    If there is no recent game data, then create new game
	    If there is a recent game data, then keep the data unchanged
	*/
	public static Minesweeper getInstance() {
		if(minesweeperInstance == null){
			minesweeperInstance = new Minesweeper();
		}
		return minesweeperInstance;
	}

	/*
		This part initialize the game entirely:
		It runs Minesweeper to check and get the game data
		And calls GUI to create a new Graphic User Interface
	*/
	public static void main(String[] args) {
		Minesweeper minesweeper = Minesweeper.getInstance();
		GUI graphicalUserInterface = new GUI();
		graphicalUserInterface.main(args);
	}
}
