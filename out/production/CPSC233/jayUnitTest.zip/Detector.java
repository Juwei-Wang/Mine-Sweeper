
/**
 * This class is a subclass of the GameObject class that has special functionality in terms of
 * detector (@see Detector).
 *
 * @documentation  Juwei Wang
 * @author Rex Leniczek
 * @version 1.1
 * @since 2019-02-15
 */


public class Detector extends GameObject {

	/**
	 * Constructor with the following parameters as arguments:
	 * @param board	A board representing board that the player currently use..
	 * @param xPos	An int representing the horizontal position of the filed.
	 * @param yPos	An int representing the vertical position of the filed.
	 */
	public Detector(Board board, int xPos, int yPos) {
		super(board, xPos, yPos);
		this.marker = (char)(43);
	}


	/**
	 * Sets the Marker to ensure the mines were put in the proper position
	 * This method overrides the setMarker method from GameObject class
	 */
	@Override
	public void setMarker() {
		// System.out.println("BoardSize: " + ownerBoard.getBoardSize());
		// System.out.println("Detector Coords: " + coords[0] + ":" + coords[1]);
		int colS, colE, rowS, rowE;
		colS = colE = rowS = rowE = 1;
		if (coords[0] == 0) colS = 0;
		else if (coords[0] == ownerBoard.getBoardSize() - 1) colE = 0;
		if (coords[1] == 0) rowS = 0;
		else if (coords[1] == ownerBoard.getBoardSize() - 1) rowE = 0;
		int scanMineCount = ownerBoard.mineScan(coords[0] - colS, coords[0] + colE, coords[1] - rowS, coords[1] + rowE);
		if (scanMineCount != 0) this.marker = (char)(scanMineCount + 48);
		else this.marker = (char)(32); 
	}
}