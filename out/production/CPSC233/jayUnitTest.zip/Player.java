//This class aims to create a player class for the game to run



//Properties Description

//   name: this properties, as its literal meaning, means the name of the player
//         name should be created by the person as the common argument

//   moveTrace : every move of the players would be recorded and appended in this array
//         this array can help the programmer to know weather the turns work properly and precisely.

//   numberOfBoneFound:
//         this properties is how many bones which the players have found in their game
//         Programmers can use this number to know which player wins the game
//         it is also the length of the arrayOfBoneFound
//         so if you want to get this number, please make sure you excute the methods
//         players.countTheNumberOfBoneFound in the first place.

//   arrayOfBoneFound:
//         this properties would record every position that the players make fit the bones correctly.

//  marker:
//        the shape of the players marker
//        for example, player1 = "*"
//        for example, player2 = "#"

import java.util.*;

public class Player {
    protected String name;
    protected ArrayList<String> moveTrace = new ArrayList<String>();
    protected int numberOfBomeFound;
    protected int[][] arrayofBomeFound;
    protected String marker;
    protected Game currentGame;


    // Constructor
    public Player(Game currentGame, String name, String marker) {
        this(currentGame);
        this.name = name;
        this.numberOfBomeFound = 0;
        this.arrayofBomeFound = new int[0][0];
        this.marker = marker;
    }

    public Player(Game currentGame, Player playerToCopy) {
        this(currentGame);
        this.name = playerToCopy.getPlayerName();
        this.moveTrace = playerToCopy.getMoveTrace();
        this.numberOfBomeFound = playerToCopy.getNumberOfBomeFound();
        this.arrayofBomeFound = playerToCopy.getArrayofBomeFound();
        this.marker = playerToCopy.getMarker();
    }

    public Player(Game currentGame) {
        this();
        this.currentGame = currentGame;
    }

    public Player() {
    }

    //Getter and Setter
    public String getPlayerName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<String> getMoveTrace() {
        return moveTrace;
    }

    public void setMoveTrace(ArrayList<String> moveTrace) {
        this.moveTrace = moveTrace;
    }

    public int getNumberOfBomeFound() {
        return numberOfBomeFound;
    }

    public void setNumberOfBomeFound(int numberOfBomeFound) {
        this.numberOfBomeFound = numberOfBomeFound;
    }

    public int[][] getArrayofBomeFound() {
        return arrayofBomeFound;
    }

    public void setArrayofBomeFound(int[][] arrayofBomeFound) {
        this.arrayofBomeFound = arrayofBomeFound;
    }

    public String getMarker() {
        return marker;
    }

    public void setMarker(String marker) {
        this.marker = marker;
    }

    // Methods
    public void addMove(String lastMove) {
        this.moveTrace.add(lastMove);
    }

    public int countTheNumberOfBomeFound(){
        this.numberOfBomeFound = this.arrayofBomeFound.length;
        return this.numberOfBomeFound;
    }
}
