
/**
 * This class is a subclass of the Player class that has special functionality in terms of
 * auto-moving robot players (@see Player).
 *
 * @documentation  Juwei Wang
 * @author Rex Leniczek
 * @version 1.1
 * @since 2019-02-15
 */

public class AI extends Player {
	private int difficulty = 0;

	/**
	 * Constructor with the following parameters as arguments:
	 * @param currentGame	A game representing the game that the player is playing.
	 */
	public AI(Game currentGame) {
		this();
		this.currentGame = currentGame;
	}


	/**
	 * Default constructor with no arguments; calls second constructor with 0  and "computer" as
	 * arguments for difficulty and name.
	 */
	public AI() {
		super();
		this.name = "Computer";
	}
}
